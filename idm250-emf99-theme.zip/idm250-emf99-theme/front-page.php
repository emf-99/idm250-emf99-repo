<?php get_header(); ?>
<h1 class="">

   <?php
   //  echo get_the_title();

   ?>

</h1>
<div class="content">
      <?php
      echo get_the_content();
      ?>
</div>

<p> this is a front-page.php file </p>

<?php get_footer(); ?>
